<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between">
            <h2>Рассылки</h2>
        </div>

        <div>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Название</th>
                    <th scope="col">Статус</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($mail->id); ?></td>
                        <td><?php echo e($mail->name); ?></td>
                        <td><?php echo e($mail->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bektemir/Desktop/my_projects/TZ/Birthday_newsletter_tz/resources/views/admin/mails/index.blade.php ENDPATH**/ ?>