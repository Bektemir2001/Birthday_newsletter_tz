<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\SMSMAilingRequest;
use App\Models\SMSMailing;
use App\Services\SMSService;
use Illuminate\Http\Response;
use Illuminate\View\View;

class SMSMailingController extends Controller
{
    protected SMSService $SMSService;

    public function __construct(SMSService $SMSService)
    {
        $this->SMSService = $SMSService;
    }

    public function index(): View
    {
        $query = SMSMailing::query();
        $mails = $query->orderBy('created_at', 'DESC')->get();
        return view('admin.mails.index', compact('mails'));
    }

    public function store(SMSMAilingRequest $request): Response
    {
        $data = $request->validated();
        $result = $this->SMSService->send($data);
        return response(['message' => $result['message']])->setStatusCode($result['status']);
    }

}
